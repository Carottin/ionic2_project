export class UserData {
  id : number;
  name:string;
  password:string;

  constructor (){
    this.id = null;
    this.name = null;
    this.password=null;
  }
}
