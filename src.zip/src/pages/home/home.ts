import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AddPage} from '../add/add';
import { PromoPage} from '../promo/promo';
import { PromoData} from '../../data/promoData';
import { ParseProvider } from "../../providers/parse/parse";
import { CategoryProvider } from "../../providers/category/category";
import { HaversineProvider } from "../../providers/haversine/haversine";
import { ReversePipe } from "../../pipes/reverse/reverse";
import { OrderByPipe } from "../../pipes/order-by/order-by";
import { Geolocation } from '@ionic-native/geolocation';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  promosList : Array<PromoData> = new Array();
  myDate: Date= new Date();
  activeCategory = ""
  constructor(public navCtrl: NavController, public parseProvider: ParseProvider, public haversineProvider:HaversineProvider,public geolocation: Geolocation, public category : CategoryProvider) {
    this.getListPromos();
    //this.myDate.setHours(this.myDate.getHours()+2);
    console.log("Il est : " + this.myDate)
    console.log("la categorie active est : " + category.category)
    //console.log("l'utilisateur est : "+category.actifUser.name)
    this.activeCategory = category.category;

  }

  getListPromos(){
    this.geolocation.getCurrentPosition().then((resp) => {
      return this.parseProvider.getPromos().then(
        (result)=> {
          for (let i = 0; i < result.length; i++) {
            if (this.activeCategory == "All" || result[i].get('category') == this.activeCategory)
            {
              let p1:PromoData = new PromoData();
              p1.title = result[i].get('title');
              p1.price = result[i].get('price');
              p1.picture = result[i].get('picture');
              p1.id = result[i].id;
              p1.description=result[i].get('description');
              p1.distance = this.haversineProvider.haversine(resp.coords.latitude,resp.coords.longitude,result[i].get('lat'),result[i].get('long'));
              this.promosList.push(p1);
              var difference = this.myDate.getTime() - result[i].get('createdAt').getTime();
              p1.timeAdded = Math.round(difference /60000);
              console.log("ajouté il y a : "+ Math.round(difference /60000))
            }
          }
        },
        (error)=>{

          console.log(error);
        }
      );
    }).catch((error) => {
      console.log('Error getting location', error);
    });
  }


  goToPromo (promo:PromoData)
  {
    console.log("la promo est : " +promo.id)
    this.navCtrl.push(PromoPage, {selectedPromo: promo});
  }

  addContent () {
    this.navCtrl.push(AddPage)
  }

  doRefresh() {
    this.navCtrl.setRoot(this.navCtrl.getActive().component);
  }

}
