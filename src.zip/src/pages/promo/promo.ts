import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PromoData} from '../../data/promoData';
import { ParseProvider } from "../../providers/parse/parse";
import { Http } from '@angular/http';

/**
 * Generated class for the PromoPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-promo',
  templateUrl: 'promo.html',
})
export class PromoPage {
  id:String;
  streetNumber:string;
  street:string;
  city:string;
  actualPromo:PromoData = new PromoData();
  myDate: Date= new Date();
  constructor(public navCtrl: NavController, public navParams: NavParams, public parseProvider : ParseProvider, public http: Http) {
    this.actualPromo.dateBegin="unkown";
    this.actualPromo.dateEnd="unkown";
    this.id = navParams.get("selectedPromo").id;
    this.getPromo();
    console.log("title : " + this.actualPromo.title)
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PromoPage');
  }

  getPromo():Promise<any> {

    return this.parseProvider.getAPromo(this.id).then(
      (result)=> {
        this.actualPromo.title = result.get('title');
        this.actualPromo.price = result.get('price');
        this.actualPromo.picture = result.get('picture');
        this.actualPromo.lat = result.get('lat');
        this.actualPromo.long = result.get('long');
        this.actualPromo.description=result.get('description');
        var difference = this.myDate.getTime() - result.get('createdAt').getTime();
        this.actualPromo.timeAdded = Math.round(difference /60000);;
        this.getAdress();
        console.log(result.get('createdAt'));
      },
      (error)=>{
        console.log(error);
      }
    );
  }

getAdress():void{
    this.http.get('http://api.opencagedata.com/geocode/v1/json?q=' + this.actualPromo.lat + '+' + this.actualPromo.long + '&key=185ac1a244594d22b4ace010b66eb84b ').map(res => res.json()).subscribe(data => {
        console.log(data.results[0].formatted);
        this.streetNumber = data.results[0].components.house_number;
        this.street = data.results[0].components.road;
        this.city = data.results[0].components.county;
    });
}



}
