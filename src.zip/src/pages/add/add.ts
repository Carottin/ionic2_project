import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { PromoData } from '../../data/promoData';
import { HomePage} from '../home/home';
import { ParseProvider } from "../../providers/parse/parse";
import { Camera, CameraOptions } from '@ionic-native/camera';
import { Http } from '@angular/http';
import { Geolocation } from '@ionic-native/geolocation';
/**
 * Generated class for the AddPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-add',
  templateUrl: 'add.html',
})
export class AddPage {

  public base64Image: string;
  promo:PromoData = new PromoData();



  constructor(public navCtrl: NavController, public navParams: NavParams, public parseProvider: ParseProvider,private camera: Camera, public http: Http, public geolocation: Geolocation) {
  }


  ionViewDidLoad() {
    console.log('ionViewDidLoad AddPage');
  }


  postPromo(){
    this.geolocation.getCurrentPosition().then((resp) => {
      this.promo.lat = resp.coords.latitude;
      this.promo.long = resp.coords.longitude;
      console.log("zen" + this.promo.lat);
      console.log("zen" + this.promo.long);
      this.promo.picture = this.base64Image;
      this.promo.nbLikes = 0;
      this.parseProvider.addPromo(this.promo)
      this.navCtrl.setRoot(HomePage)
      //this.navCtrl.push(HomePage)
    }).catch((error) => {
      console.log('Error getting location', error);
    });

  }

getPosition(){

}

takePicture(){
  this.camera.getPicture({
      destinationType: this.camera.DestinationType.DATA_URL,
      targetWidth: 1000,
      targetHeight: 1000
  }).then((imageData) => {
    // imageData is a base64 encoded string
      this.base64Image = "data:image/jpeg;base64," + imageData;
      var url = 'http://uploads.im/api?upload=' + this.base64Image;
      var response = this.http.get(url).map(res => res.json());
  }, (err) => {
      console.log(err);
  });
}
}
